from django.apps import AppConfig


class TvAppConfig(AppConfig):
    name = 'tv_app'
